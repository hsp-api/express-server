const express = require('express');

const hspRouter = express.Router();

const axios = require('axios');

function ConnectUserController() {
}

ConnectUserController.prototype.userDetails = function (request, response) {
    
    axios.post(`https://ghs-hsp-dotnet-w-service01.azurewebsites.net/common/api/Common/ConnectUser`, request.body)
        .then(res => {
            console.log(res);
    response.json({ data: res, ok: true });
            
        })
}

module.exports = ConnectUserController;
const express = require('express');

const hspRouter = express.Router();

const axios = require('axios');

function GetFindControlsController() {
}

GetFindControlsController.prototype.getControls = function (request, response) {

    axios.post(`https://ghs-hsp-dotnet-w-service01.azurewebsites.net/common/api/Common/GetFindControls`, request.body)
        .then(res => {
            response.json({ data: res, ok: true });
        })
}

module.exports = GetFindControlsController;
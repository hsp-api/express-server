const express = require('express');

const axios = require('axios');

function GetFindProfilesController() {
}

GetFindProfilesController.prototype.findProfiles = function (request, response) {

    axios.post(`https://ghs-hsp-dotnet-w-service01.azurewebsites.net/common/api/Common/GetFindProfiles`, request.body)
        .then(res => {
            response.json({ data: res, ok: true });
        })
}

module.exports = GetFindProfilesController;
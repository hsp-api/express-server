const express = require('express');

const axios = require('axios');

function GetFindCommandsController() {
}

GetFindCommandsController.prototype.getCommands = function (request, response) {

    axios.post(`https://ghs-hsp-dotnet-w-service01.azurewebsites.net/common/api/Common/GetFindCommands`, request.body)
        .then(res => {
            response.json({ data: res, ok: true });

        })
}

module.exports = GetFindCommandsController;
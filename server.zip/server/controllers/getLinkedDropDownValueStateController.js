const express = require('express');

const axios = require('axios');

function GetLinkedDropDownController() {
}

GetLinkedDropDownController.prototype.getLinkedDropDownValue = function (request, response) {

    axios.post(`https://ghs-hsp-dotnet-w-service01.azurewebsites.net/common/api/Common/GetLinkedDropDownValue`, request.body)
        .then(res => {
            response.json({ data: res, ok: true });
        })
}

module.exports = GetLinkedDropDownController;